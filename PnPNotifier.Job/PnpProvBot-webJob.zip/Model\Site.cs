﻿namespace PnPNotifier.Job.Model
{
    public class Site
    {
        public string WebUrl { get; set; }
    }
}
